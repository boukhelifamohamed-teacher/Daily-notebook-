package com.teacher.dailynotebook;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private static final String HOST = "appassets.androidplatform.net";
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> chooserLauncher;
    private ActivityResultLauncher<Intent> createDocLauncher;

    private int pendingId = -1;
    private byte[] pendingBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        chooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    Uri[] uris = null;
                    if (result.getResultCode() == RESULT_OK && result.getData() != null
                            && result.getData().getData() != null) {
                        uris = new Uri[]{result.getData().getData()};
                    }
                    if (filePathCallback != null) {
                        filePathCallback.onReceiveValue(uris);
                        filePathCallback = null;
                    }
                });

        createDocLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    int id = pendingId;
                    byte[] bytes = pendingBytes;
                    pendingId = -1;
                    pendingBytes = null;
                    boolean ok = false;
                    if (result.getResultCode() == RESULT_OK && result.getData() != null
                            && result.getData().getData() != null && bytes != null) {
                        ok = writeAndVerify(result.getData().getData(), bytes);
                        Toast.makeText(this, ok ? "تم حفظ الملف" : "فشل حفظ الملف",
                                Toast.LENGTH_SHORT).show();
                    }
                    notifyJs(id, ok);
                });

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100); // لا تتأثر أبعاد الصفحة بحجم خط النظام (مهم لتصدير PDF)
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    chooserLauncher.launch(Intent.createChooser(i, "اختر ملف JSON"));
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("https://" + HOST + "/assets/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    /** يكتب الملف ثم يتحقق من حجمه الفعلي للتأكد من نجاح الحفظ. */
    private boolean writeAndVerify(Uri uri, byte[] bytes) {
        try (OutputStream os = getContentResolver().openOutputStream(uri, "wt")) {
            if (os == null) return false;
            os.write(bytes);
            os.flush();
        } catch (Exception e) {
            return false;
        }
        try (AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(uri, "r")) {
            if (afd == null) return true;
            long len = afd.getLength();
            return len == AssetFileDescriptor.UNKNOWN_LENGTH || len == bytes.length;
        } catch (Exception e) {
            return true; // كُتب الملف بنجاح لكن تعذر قراءة حجمه
        }
    }

    private void notifyJs(int id, boolean ok) {
        if (id < 0) return;
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__androidSaveDone(" + id + "," + ok + ")", null));
    }

    private class Bridge {
        @JavascriptInterface
        public void saveFile(int id, String base64, String filename, String mime) {
            try {
                final byte[] data = Base64.decode(base64, Base64.DEFAULT);
                final String cleanMime = (mime == null || mime.isEmpty())
                        ? "application/octet-stream" : mime.split(";")[0].trim();
                runOnUiThread(() -> {
                    pendingId = id;
                    pendingBytes = data;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(cleanMime);
                    i.putExtra(Intent.EXTRA_TITLE, filename);
                    try {
                        createDocLauncher.launch(i);
                    } catch (Exception e) {
                        pendingId = -1;
                        pendingBytes = null;
                        notifyJs(id, false);
                    }
                });
            } catch (Exception e) {
                notifyJs(id, false);
            }
        }
    }
}
