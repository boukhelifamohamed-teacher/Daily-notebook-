// يختبر منطق حفظ الملفات (JSON/PDF) عبر الجسر الأصلي دون الحاجة لهاتف
const fs = require('fs');
const html = fs.readFileSync(__dirname + '/../app/src/main/assets/index.html', 'utf8');
const m = html.match(/\/\*BRIDGE-START\*\/([\s\S]*?)\/\*BRIDGE-END\*\//);
if (!m) { console.error('FAIL: bridge block not found'); process.exit(1); }
global.window = global;
const saved = {};
function run(label, bytes, type, name, ok) {
  window.AndroidBridge = { saveFile(id, b64, fname, mime) {
    saved[id] = { data: Buffer.from(b64, 'base64'), fname, mime };
    setTimeout(() => window.__androidSaveDone(id, ok), 5);
  }};
  return saveViaAndroid(new Blob([bytes], { type }), name).then(res => {
    const rec = Object.values(saved).pop();
    const same = Buffer.compare(rec.data, Buffer.from(bytes)) === 0;
    if (res !== ok || !same || rec.fname !== name) { console.error('FAIL', label); process.exit(1); }
    console.log('PASS', label, '(' + rec.data.length + ' bytes)');
  });
}
eval(m[1] + ';global.saveViaAndroid=saveViaAndroid;');
(async () => {
  const json = Buffer.from(JSON.stringify({ teacherData: { name: 'أحمد' }, entries: [1, 2, 3] }, null, 2), 'utf8');
  await run('JSON (Arabic, utf-8)', json, 'application/json;charset=utf-8', 'الكراس-اليومي.json', true);
  const pdf = Buffer.alloc(900000); for (let i = 0; i < pdf.length; i++) pdf[i] = i % 256;
  await run('PDF (binary 900KB)', pdf, 'application/pdf', 'الكراس-اليومي.pdf', true);
  await run('user cancels save dialog', json, 'application/json', 'x.json', false);
  console.log('ALL OK');
})();
